//
//  DrilldownApp.swift
//  Drilldown
//
//  Created by Peter Friese on 05.07.21.
//

import SwiftUI

@main
struct DrilldownApp: App {
  var body: some Scene {
    WindowGroup {
      ContentView()
    }
  }
}
