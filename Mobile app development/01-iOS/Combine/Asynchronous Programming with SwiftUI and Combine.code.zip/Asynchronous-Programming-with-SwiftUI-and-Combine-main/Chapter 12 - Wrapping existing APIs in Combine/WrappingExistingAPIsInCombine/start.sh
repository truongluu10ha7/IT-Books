#!/bin/bash
firebase emulators:start --import=./data --export-on-exit
