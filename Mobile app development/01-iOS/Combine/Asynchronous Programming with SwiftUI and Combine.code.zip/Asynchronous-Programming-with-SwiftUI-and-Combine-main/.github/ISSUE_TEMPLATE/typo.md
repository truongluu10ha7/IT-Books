---
name: Typo
about: Found a typo in the book? Submit it here so I can fix it in the next issue.
title: "[TYPO]"
labels: typo
assignees: peterfriese

---

I found a typo in _Asynchronous Programming  with SwiftUI and Combine_.

* Edition: 1st
* Page: <please insert the page number here>

### What is wrong
(Please insert the misspelled word, including some context, so it is easier to find.)

### What's the correct spelling
(Please insert the correctly spelled word.)
