# Getting Started with Combine

I recommend opening this Xcode Playground with the Playgrounds app for macOS. While it is possible to open it in Xcode, you will have a nicer experience by using the standalone Playgrounds app.

![](PlaygroundsApp.png)

## How to use this

### Finding your way around

- Open the playground file in the Playgrounds app. 
- Navigate around using the outline on the left. the _< Previous_, _Home_, _Next >_ links on the playground pages, and the links in the table of contents

### Running the code

- Open the console (by clicking on the button at the bottom right)
- Run the code by clicking the _Run_ button

![](Running.png)