//
//  FormsExamplesApp.swift
//  FormsExamples
//
//  Created by Peter Friese on 02.03.21.
//

import SwiftUI

@main
struct FormsExamplesApp: App {
  var body: some Scene {
    WindowGroup {
      ContentView()
    }
  }
}
