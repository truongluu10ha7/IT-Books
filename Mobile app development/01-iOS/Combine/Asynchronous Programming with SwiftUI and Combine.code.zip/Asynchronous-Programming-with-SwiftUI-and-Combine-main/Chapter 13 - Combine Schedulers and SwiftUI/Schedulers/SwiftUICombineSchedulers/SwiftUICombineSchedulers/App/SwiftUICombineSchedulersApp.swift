//
//  SwiftUICombineSchedulersApp.swift
//  SwiftUICombineSchedulers
//
//  Created by Peter Friese on 25.04.22.
//

import SwiftUI

@main
struct SwiftUICombineSchedulersApp: App {
  var body: some Scene {
    WindowGroup {
      NavigationStack {
        MenuView()
      }
    }
  }
}
