/*:

 Follow the chapter and open the appropriate page for each part

 */
